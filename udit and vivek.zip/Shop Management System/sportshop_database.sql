--
--  Sports Shop Management System
--    UDIT CHIRANIA
--

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`shopkeeper` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `shopkeeper`;

--
-- Definition of table `login`
--

DROP TABLE IF EXISTS `login`;
CREATE TABLE `login` (
  `userid` varchar(20) NOT NULL,
  `password` varchar(20) NOT NULL,
  PRIMARY KEY (`userid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `login`
--

INSERT INTO `login` VALUES 
('mritunjay','khichi'),
('netbeans','mysql');

/*Table structure for table `item` */

DROP TABLE IF EXISTS `item`;

CREATE TABLE `item` (
  `item_id` int(100) DEFAULT NULL,
  `item_name` varchar(100) DEFAULT NULL,
  `description` varchar(1000) DEFAULT NULL,
  `PRICE` float(11,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `item` */

insert  into `item`(`item_id`,`item_name`,`description`,`PRICE`) values (100,'SHOE\"S','NIVA',850.00),(101,'TRACK SUIT','SHIV NARESH',1500.50),(103,'BAT','REEBOK',650.00),(1,'kit','mine',500.00);

/*Table structure for table `orderitem` */

DROP TABLE IF EXISTS `orderitem`;

CREATE TABLE `orderitem` (
  `orderno` varchar(100) DEFAULT NULL,
  `orderDate` date DEFAULT NULL,
  `item_id` int(100) DEFAULT NULL,
  `shopper_id` varchar(100) DEFAULT NULL,
  `quantity` int(100) DEFAULT NULL,
  `price` float(11,2) DEFAULT NULL,
  `discount` float(11,2) DEFAULT NULL,
  `amount` float(11,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `orderitem` */

insert  into `orderitem`(`orderno`,`orderDate`,`item_id`,`shopper_id`,`quantity`,`price`,`discount`,`amount`) values ('01','2012-01-30',100,'100',1,850.00,5.00,807.50),
('02','2012-01-30',101,'101',1,1500.50,0.00,1500.50),
('03','2012-01-30',103,'102',1,650.00,8.00,598.00),
('12','2015-04-04',103,'102',1,650.00,10.00,585.00);



/*Table structure for table `shopkeeper` */

DROP TABLE IF EXISTS `shopkeeper`;

CREATE TABLE `shopkeeper` (
  `shopper_id` int(100) DEFAULT NULL,
  `name` varchar(100) DEFAULT NULL,
  `city` varchar(100) DEFAULT NULL,
  `phone` varchar(11) DEFAULT NULL,
  `address` varchar(40) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `shopkeeper` */

insert  into `shopkeeper`(`shopper_id`,`name`,`city`,`phone`,`address`) values (100,'Deepak yadav','dehradun','9456548099','C/O sagar sahi anarwala'),(101,'ankit aswal','dehradun','8650017068','cidbag vijay colony'),(102,'Issarar ali','dehradun','9410506257','garhi cantt'),(1,'mukesh','hamirpur','938388888','bohni'),(1,'mukesh','hamirpur','9418200424','hamirpur'),(102,'rajesh','hamirpur','9418200424','hamirpur');

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
